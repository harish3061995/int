// highest numnber without inbuild method
var numbersList = [3, 4, 34, 5, 4, 5, 4, 5, 45, 465, 67, 7];
var heightNumber = numbersList[0];
// inbuildMethod
console.log(Math.min(...numbersList));
console.log(Math.max(...numbersList));

// non inbuild method
numbersList.forEach((num) => {
  if (num > heightNumber) {
    heightNumber = num;
  }
});

console.log(heightNumber);

// evenNumber
console.log(
  numbersList.filter(function (x) {
    return x % 2 === 0;
  })
);

const person = [
  {
    name: "John",
    age: 30,
    city: "New York",
  },
  {
    name: "kevin",
    age: 30,
    city: "chennai",
  },
  {
    name: "alex",
    age: 30,
    city: "cmbt",
  },
  {
    name: "bob",
    age: 30,
    city: "mdu",
  },
];

person.map((val) => {
  return console.log(val.name);
});

// rediuce 2d array
let arrtwod = [
  [1, 2],
  [4, 6],
  [7, 8],
];
