let a = 1;
let b = "asdf";
let c = null;
let d;
let e = undefined;

console.log(typeof a);
console.log(typeof b);
console.log(typeof c);
console.log(typeof d);
console.log(typeof e);
console.log(null !== undefined);
console.log(null === undefined);

const s1 = Symbol();
const s2 = Symbol();
console.log(s1, s2);
console.log(s1 === s2);
let courses = ["html", "css", "js"];
console.log(courses);
console.log(typeof courses);

let tempObj = {
  name: "hari",
  age: "12",
};
console.log(tempObj);
console.log(typeof tempObj);

let date = new Date();
console.log(date);
console.log(typeof date);

let num; //number to date to string
num = 10;
console.log(num, typeof num);
num = String(num);
console.log(num, typeof num);

let f = true;
let g = false;
console.log(f, typeof f);
f = Number(f);
console.log(f, typeof f);

console.log(g, typeof g);

// type coercion

let h = "25";
let i = 10;
console.log(h + i);
console.log(i + h);

// loop

// while
let j = 1;
while (j < 5) {
  console.log(j);
  j++;
}

// do while
let table = 2,
  limit = 5,
  k = 1;
do {
  console.log(table + "X" + k + "=" + table * k);
  k++;
} while (k <= limit);

// for
let arr = [];
for (let i = 1; i <= 10; i += 2) {
  arr.push(i);
}
console.log(arr);

// nested for loop

let twoDarr = [];

for (let i = 0; i < 3; i++) {
  twoDarr.push([]);
  for (let j = 0; j < 3; j++) {
    twoDarr[i].push(j * 2);
  }
}
console.table(twoDarr);

// for of
let names = ["asdf", "wqer", "qwer", "asdarfwe", "dhjre"];
for (let name of names) {
  console.log(name);
}

let userObj = {
  name: "asdf",
  age: 12,
  city: "chennai",
};

// for in
for (let prop in userObj) {
  console.log(prop + " : " + userObj[prop]);
}

// obj to array
let objKeyList = Object.keys(userObj);
let objValList = Object.values(userObj);
console.log(objKeyList);
console.log(objValList);

// obj to array winthout inbuild method
let keyList = [],
  vale = [];
for (const key in userObj) {
  keyList.push(key);
  vale.push(userObj[key]);
}

console.log(keyList);
console.log(vale);

// print odd number
for (let i = 0; i <= 10; i++) {
  if (i % 2 == 0) {
    continue;
  } else {
    console.log(i);
  }
}

// label Block

// first accourens of R letter
let grps = [
  ["ram", "sam", "ravi"],
  ["kumar", "tiya", "sunder"],
  ["rajesh", "sara", "rahul"],
];
for (grp of grps) {
  inner: for (let member of grp) {
    if (member.startsWith("r")) {
      console.log(member);
      break inner;
      // continue;
    }
  }
}

console.clear();
// string

let l = "asdf",
  m = "qwer",
  n;
n = l + m; //or
n = l.concat(" ", m);
// n = n.toUpperCase();
console.log(n);
console.log(n.indexOf("f"));
console.log(n.lastIndexOf("f"));
console.log(n.charAt(1));
console.log(n.charCodeAt(2));
console.log(n.substr(0, 3));
console.log(n.substring(2, 5));
console.log(n.substring(2));
console.log("slice " + n.slice(2, 4));
console.log(n.slice(40, 20));
console.log(n.slice(-3));
// split
console.log(n.split(""));
console.log(n.split("").filter((val) => val != " "));
console.log("replace " + n.replace("asdf", "zcxv"));
console.log(grps[0].includes("ram"));
console.log(" qwe ".trim());
console.log("a".padStart(5, "$"));
console.log("a".padEnd(5, "@"));

// function
function add(a, b) {
  return a + b;
}
console.log(add(1, 2));

// function arbitrary argument

function add1() {
  let total = 0;
  for (let i = 0; i < arguments.length; i++) {
    total = total + arguments[i];
  }
  return total;
}
console.log(add1(11, 2, 32, 234, 6, 6, 66, 0, 6, 7, 7));

function add1(...arg) {
  let total = 0;
  for (let i = 0; i < arg.length; i++) {
    total = total + arg[i];
  }
  return total;
}
console.log(add1(11, 2, 32, 234, 6, 6, 66, 0, 6, 7, 7));

// function as expression
const add2 = (a, b) => {
  {
    return a + b;
  }
};
console.log(add2(2, 3));

// map
let o = ["", 1, 2, 3, 4, 5, 6, 7];
console.log(o.map((num) => num * 2));

// filter
let p = ["apple", "banana", "orange", "grap", "qwerqwer"];
console.log(p.filter((fru) => fru.length > 5));

// reduce
let q = [1, 2, 3, 2, 4];
console.log(q.reduce((acc, currentVal) => acc + currentVal, 0));

// closure
let counter = () => {
  let count = 0;
  return () => {
    count++;
    return count;
  };
};
let tempCounter = counter();
console.log(counter()());
console.log(tempCounter());
console.log(tempCounter());
console.log(tempCounter());

// callbackfunction

function mycallback() {
  console.log("callback");
}
function higherorderFunction(mycallback) {
  mycallback();
}
setTimeout(() => {
  console.log("setTimeout" + 3000);
}, 3000);

let setIntervalvar = setInterval(() => {
  console.log("setInterval" + 3000);
  clearInterval(setIntervalvar);
}, "3000");

// block level scope
if (true) {
  let asdf = "asdf";
  console.log(asdf);
}
// console.log(asdf);

// function level scope
function myfun() {
  var a = "myfun";
  console.log(a);
  function myfun2() {
    console.log(a);
  }
  myfun2();
}
myfun();

// array
let array = new Array(1, 2, 3, 4, 5);
let array1 = [1, 2, 3, 4, 5];
let array2 = new Array(1, "asdf", true, { name: "harish", age: 20 });
console.log(array, array1, array2);

// array method
const number = [1, 2, 3, 4, 5, 6, 7, 8, 9];
// for each
number.forEach((value, index, array) => {
  console.log("value=" + value, "index=" + index, array);
});

// map
number.map((val, ind) => {
  console.log(Math.sqrt(val));
});
